import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
    title = 'DXC Cuisine Angular';
    constructor(private service: SharedService) {
    }

   

    AppetizersFood: string = "Appetizers & Snacks Recipes";
    BreakfastFood: string = "Breakfast & Brunch Recipes";
    DessertsFood: string = "Desserts";
    DinnersFood: string = "Dinners";
    Drinks: string ="Drinks";
    
    txtSearchFood: string = '';
    FoodListSearch: any=[];
    
    FoodList: any = [];
    card_items = [];
    scroll_left_value = 0;
    max_width = 0;
    ActivateAddEditFood: boolean = false;
    food: any;
    ModelTitle: string;
    ngOnInit(): void {
        this.refreshFoodList();
    }

    btnPrevious() {
        
        document.getElementById('ctnPopularFood').scrollLeft -= 200;
    }

    btnNext() {
        document.getElementById('ctnPopularFood').scrollLeft += 200;
    }
    refreshFoodList() {
        this.service.getFoodList().subscribe(data => {
            this.FoodList = data;
            this.FoodListSearch=data
        })
    
    }
    addClick() {
        this.food = {
            id: 0,
            imgsrc: "",
            title: "",
            desc: "",
            mealType: "",
        }
        this.ModelTitle = "Add New Food";
        this.ActivateAddEditFood = true;
    }
    editClick(item) {
        this.food = item;
        this.ModelTitle = "Update Food";
        this.ActivateAddEditFood = true;
    }
    closeClick() {
        this.ActivateAddEditFood = false;
        this.refreshFoodList();
    }
    deleteClick(val:any){
        let alertConfirm = confirm("Are you sure to delete this Food?")
        if(alertConfirm)
        {
            this.service.deleteFood(val).subscribe(Response =>{
                if(Response){
                    alert('Food is deleted successfully!!!');
                    this.refreshFoodList();
                }
            })
        }
    }
    searchFood(itemFood){
        itemFood = this.txtSearchFood;
        this.FoodList = this.FoodListSearch.filter(res =>{
            return (res.title.toLocaleLowerCase().match(itemFood.toLocaleLowerCase()) || res.desc.toLocaleLowerCase().match(itemFood.toLocaleLowerCase()));
        })
    }
    searchFoodCheck(){
        if (this.txtSearchFood=="")
            this.refreshFoodList();
    
    }

    

    searchAppetizersFood(){
        this.FoodList=this.FoodListSearch.filter(res =>{
            return (res.mealType.toLocaleLowerCase().match(this.AppetizersFood.toLocaleLowerCase()));
        })
    }

    searchBreakfastFood(){
        this.FoodList=this.FoodListSearch.filter(res =>{
            return (res.mealType.toLocaleLowerCase().match(this.BreakfastFood.toLocaleLowerCase()));
        })
    }
    
    searchDessertsFood(){
        this.FoodList=this.FoodListSearch.filter(res =>{
            return (res.mealType.toLocaleLowerCase().match(this.DessertsFood.toLocaleLowerCase()));
        })
    }

    searchDinnersFood(){
        this.FoodList=this.FoodListSearch.filter(res =>{
            return (res.mealType.toLocaleLowerCase().match(this.DinnersFood.toLocaleLowerCase()));
        })
    }

    searchDrinks(){
        this.FoodList=this.FoodListSearch.filter(res =>{
            return (res.mealType.toLocaleLowerCase().match(this.Drinks.toLocaleLowerCase()));
        })
    }
}